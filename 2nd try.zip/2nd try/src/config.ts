/**
 * Centralized configuration module.
 * Loads environment variables and exposes typed config objects.
 */
import dotenv from "dotenv";
dotenv.config();

export interface JiraConfig {
  email: string;
  apiToken: string;
  domain: string;
  baseUrl: string;
}

export interface FigmaConfig {
  accessToken: string;
  baseUrl: string;
}

export interface GitHubConfig {
  token: string;
  apiUrl: string;
}

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value || value === "dummy" || value.startsWith("your-")) {
    console.error(
      `⚠️  Warning: Environment variable ${name} is not configured. Related tools will fail.`
    );
    return value ?? "";
  }
  return value;
}

export const jiraConfig: JiraConfig = {
  email: requireEnv("JIRA_EMAIL"),
  apiToken: requireEnv("JIRA_API_TOKEN"),
  domain: requireEnv("JIRA_DOMAIN"),
  get baseUrl() {
    return `https://${this.domain}/rest/api/3`;
  },
};

export const figmaConfig: FigmaConfig = {
  accessToken: requireEnv("FIGMA_ACCESS_TOKEN"),
  baseUrl: "https://api.figma.com/v1",
};

export const githubConfig: GitHubConfig = {
  token: requireEnv("GITHUB_TOKEN"),
  apiUrl: "https://api.github.com",
};
