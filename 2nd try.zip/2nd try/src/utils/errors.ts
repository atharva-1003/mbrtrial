/**
 * Custom error classes for structured error handling.
 */

export class ToolError extends Error {
  public readonly toolName: string;
  public readonly details?: unknown;

  constructor(toolName: string, message: string, details?: unknown) {
    super(message);
    this.name = "ToolError";
    this.toolName = toolName;
    this.details = details;
  }
}

export class ConfigError extends Error {
  constructor(service: string, message: string) {
    super(`[${service}] Configuration error: ${message}`);
    this.name = "ConfigError";
  }
}

export class ApiError extends Error {
  public readonly statusCode?: number;
  public readonly response?: unknown;

  constructor(service: string, message: string, statusCode?: number, response?: unknown) {
    super(`[${service}] API error: ${message}`);
    this.name = "ApiError";
    this.statusCode = statusCode;
    this.response = response;
  }
}

/**
 * Safely extract an error message from an unknown thrown value.
 */
export function getErrorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  return JSON.stringify(error);
}
