/**
 * Logger utility.
 * MCP servers communicate over stdio, so all logging MUST go to stderr.
 */

export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
}

const LOG_LEVEL = (process.env.LOG_LEVEL as keyof typeof LogLevel) ?? "INFO";
const currentLevel = LogLevel[LOG_LEVEL] ?? LogLevel.INFO;

function timestamp(): string {
  return new Date().toISOString();
}

export const logger = {
  debug(message: string, ...args: unknown[]) {
    if (currentLevel <= LogLevel.DEBUG) {
      console.error(`[${timestamp()}] DEBUG: ${message}`, ...args);
    }
  },

  info(message: string, ...args: unknown[]) {
    if (currentLevel <= LogLevel.INFO) {
      console.error(`[${timestamp()}] INFO: ${message}`, ...args);
    }
  },

  warn(message: string, ...args: unknown[]) {
    if (currentLevel <= LogLevel.WARN) {
      console.error(`[${timestamp()}] WARN: ${message}`, ...args);
    }
  },

  error(message: string, ...args: unknown[]) {
    if (currentLevel <= LogLevel.ERROR) {
      console.error(`[${timestamp()}] ERROR: ${message}`, ...args);
    }
  },
};
