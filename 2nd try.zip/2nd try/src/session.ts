/**
 * Session Context Manager
 * 
 * Maintains state across tool invocations within a session:
 * - Active Jira ticket
 * - Current Git branch / repository
 * - Linked Figma design
 */

export interface SessionContext {
  activeTicket: {
    key: string;
    summary: string;
    figmaLink: string | null;
  } | null;
  currentRepo: {
    owner: string;
    repo: string;
    localPath: string | null;
    branch: string | null;
  } | null;
  linkedFigma: {
    url: string;
    fileKey: string;
    nodeId: string | null;
  } | null;
  history: { tool: string; timestamp: string; summary: string }[];
}

class SessionManager {
  private context: SessionContext = {
    activeTicket: null,
    currentRepo: null,
    linkedFigma: null,
    history: [],
  };

  getContext(): SessionContext {
    return { ...this.context };
  }

  setActiveTicket(key: string, summary: string, figmaLink: string | null) {
    this.context.activeTicket = { key, summary, figmaLink };
    if (figmaLink) {
      const fkMatch = figmaLink.match(/(?:file|design)\/([a-zA-Z0-9]+)\//);
      const fileKey = fkMatch ? fkMatch[1] : null;
      if (fileKey) {
        let nodeId: string | null = null;
        try { nodeId = new URL(figmaLink).searchParams.get("node-id"); } catch {}
        this.context.linkedFigma = { url: figmaLink, fileKey, nodeId };
      }
    }
  }

  clearActiveTicket() {
    this.context.activeTicket = null;
    this.context.linkedFigma = null;
  }

  setCurrentRepo(owner: string, repo: string, localPath: string | null, branch: string | null) {
    this.context.currentRepo = { owner, repo, localPath, branch };
  }

  setBranch(branch: string) {
    if (this.context.currentRepo) {
      this.context.currentRepo.branch = branch;
    }
  }

  setLinkedFigma(url: string, fileKey: string, nodeId: string | null) {
    this.context.linkedFigma = { url, fileKey, nodeId };
  }

  addHistory(tool: string, summary: string) {
    this.context.history.push({
      tool,
      timestamp: new Date().toISOString(),
      summary,
    });
    // Keep last 50 entries
    if (this.context.history.length > 50) {
      this.context.history = this.context.history.slice(-50);
    }
  }

  reset() {
    this.context = {
      activeTicket: null,
      currentRepo: null,
      linkedFigma: null,
      history: [],
    };
  }
}

// Singleton
export const session = new SessionManager();
