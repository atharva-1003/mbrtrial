/**
 * Figma Webhook Watcher
 * 
 * Polls a Figma file for changes at a configurable interval.
 * When a version change is detected:
 *   1. Fetches the diff (new version vs. old version) 
 *   2. Auto-creates a Jira ticket with the Figma link
 *   3. Logs the event for the MCP session
 * 
 * Why polling instead of real webhooks?
 *   - Figma webhooks require an internet-accessible endpoint (not localhost)
 *   - Polling works out-of-the-box for local dev without tunnels
 *   - We poll /files/:key for the `version` and `lastModified` fields
 */
import { figmaConfig } from "../config.js";
import { getFileInfo } from "../clients/figma.js";
import { createIssue, CreatedIssue } from "../clients/jira-create.js";
import { logger } from "../utils/logger.js";
import { getErrorMessage } from "../utils/errors.js";

// ═══════════════════════════════════════════════
// Types
// ═══════════════════════════════════════════════

export interface WatchConfig {
  figmaFileKey: string;
  figmaUrl: string;
  jiraProjectKey: string;
  pollIntervalMs?: number;    // default: 60000 (1 minute)
  autoAssign?: boolean;       // default: true
  labels?: string[];          // extra labels for created issues
  targetRepo?: {              // optional: auto-link to a GitHub repo
    owner: string;
    repo: string;
    branch?: string;
  };
}

export interface WatchEvent {
  timestamp: string;
  type: "started" | "change_detected" | "ticket_created" | "error" | "stopped";
  message: string;
  details?: unknown;
}

interface WatchState {
  config: WatchConfig;
  lastVersion: string | null;
  lastModified: string | null;
  isRunning: boolean;
  timer: ReturnType<typeof setInterval> | null;
  events: WatchEvent[];
  createdTickets: CreatedIssue[];
}

// ═══════════════════════════════════════════════
// Singleton Watcher
// ═══════════════════════════════════════════════

const watches = new Map<string, WatchState>();

function addEvent(state: WatchState, type: WatchEvent["type"], message: string, details?: unknown) {
  const event: WatchEvent = {
    timestamp: new Date().toISOString(),
    type,
    message,
    details,
  };
  state.events.push(event);
  // Keep last 100 events
  if (state.events.length > 100) {
    state.events = state.events.slice(-100);
  }
  logger.info(`[FigmaWatch:${state.config.figmaFileKey}] ${type}: ${message}`);
}

async function pollForChanges(state: WatchState): Promise<void> {
  try {
    const fileInfo = await getFileInfo(state.config.figmaFileKey);
    const currentVersion = fileInfo.version;
    const currentModified = fileInfo.lastModified;

    // First poll — just record the baseline
    if (state.lastVersion === null) {
      state.lastVersion = currentVersion;
      state.lastModified = currentModified;
      addEvent(state, "started", `Baseline set: version ${currentVersion}, modified ${currentModified}`);
      return;
    }

    // No change
    if (currentVersion === state.lastVersion) {
      return;
    }

    // ─── CHANGE DETECTED ────────────────────────
    addEvent(state, "change_detected", 
      `Figma file changed! Version ${state.lastVersion} → ${currentVersion}`,
      { oldVersion: state.lastVersion, newVersion: currentVersion, lastModified: currentModified, fileName: fileInfo.name }
    );

    // Build ticket summary
    const summary = `[Figma Update] ${fileInfo.name} — design changed (v${currentVersion})`;
    const description = [
      `A design change was detected in Figma file "${fileInfo.name}".`,
      ``,
      `• Previous version: ${state.lastVersion}`,
      `• New version: ${currentVersion}`,
      `• Last modified: ${currentModified}`,
      `• Pages: ${fileInfo.pages.map(p => p.name).join(", ")}`,
      ``,
      `Please review the Figma design and update the implementation accordingly.`,
    ].join("\n");

    // Create Jira ticket
    try {
      const ticket = await createIssue({
        projectKey: state.config.jiraProjectKey,
        summary,
        description,
        issueType: "Task",
        assignToSelf: state.config.autoAssign !== false,
        labels: [...(state.config.labels ?? []), "figma-auto", "design-update"],
        figmaUrl: state.config.figmaUrl,
      });

      state.createdTickets.push(ticket);
      addEvent(state, "ticket_created",
        `Jira ticket created: ${ticket.key} — ${ticket.url}`,
        ticket
      );
    } catch (e) {
      addEvent(state, "error", `Failed to create Jira ticket: ${getErrorMessage(e)}`);
    }

    // Update baseline
    state.lastVersion = currentVersion;
    state.lastModified = currentModified;

  } catch (e) {
    addEvent(state, "error", `Poll error: ${getErrorMessage(e)}`);
  }
}

// ═══════════════════════════════════════════════
// Public API
// ═══════════════════════════════════════════════

/**
 * Start watching a Figma file for changes.
 */
export function startWatch(config: WatchConfig): string {
  const key = config.figmaFileKey;

  if (watches.has(key)) {
    return `Already watching Figma file ${key}. Call figma_stop_watch first.`;
  }

  const interval = config.pollIntervalMs ?? 60000;

  const state: WatchState = {
    config,
    lastVersion: null,
    lastModified: null,
    isRunning: true,
    timer: null,
    events: [],
    createdTickets: [],
  };

  // Do first poll immediately
  pollForChanges(state);

  // Then poll at interval
  state.timer = setInterval(() => pollForChanges(state), interval);

  watches.set(key, state);

  return `Started watching Figma file ${key} every ${interval / 1000}s. Jira tickets will be created in project ${config.jiraProjectKey} when changes are detected.`;
}

/**
 * Stop watching a Figma file.
 */
export function stopWatch(figmaFileKey: string): string {
  const state = watches.get(figmaFileKey);
  if (!state) {
    return `No active watch for Figma file ${figmaFileKey}.`;
  }

  if (state.timer) clearInterval(state.timer);
  state.isRunning = false;
  addEvent(state, "stopped", "Watch stopped by user.");
  watches.delete(figmaFileKey);

  return `Stopped watching Figma file ${figmaFileKey}. Created ${state.createdTickets.length} tickets during this watch.`;
}

/**
 * Get the status of all active watches.
 */
export function getWatchStatus(): object {
  const result: any[] = [];
  for (const [key, state] of watches) {
    result.push({
      figmaFileKey: key,
      figmaUrl: state.config.figmaUrl,
      jiraProject: state.config.jiraProjectKey,
      isRunning: state.isRunning,
      lastVersion: state.lastVersion,
      lastModified: state.lastModified,
      ticketsCreated: state.createdTickets.length,
      recentEvents: state.events.slice(-10),
      createdTickets: state.createdTickets,
    });
  }
  return result.length === 0
    ? { message: "No active Figma watches. Use figma_start_watch to begin monitoring." }
    : result;
}

/**
 * Stop all active watches.
 */
export function stopAllWatches(): string {
  const count = watches.size;
  for (const key of [...watches.keys()]) {
    stopWatch(key);
  }
  return `Stopped ${count} active watch(es).`;
}
