/**
 * Figma API Client
 */
import axios, { AxiosInstance } from "axios";
import { figmaConfig } from "../config.js";
import { logger } from "../utils/logger.js";
import { ApiError, getErrorMessage } from "../utils/errors.js";

export interface FigmaFileInfo {
  name: string;
  lastModified: string;
  version: string;
  pages: { name: string; id: string; childCount: number }[];
}

export interface FigmaDesignSpec {
  component: string;
  layout: string;
  dimensions: { width: number; height: number };
  styles: Record<string, unknown>;
  children: FigmaDesignSpec[];
  text?: string;
}

function createClient(): AxiosInstance {
  if (!figmaConfig.accessToken) {
    throw new ApiError("Figma", "Missing FIGMA_ACCESS_TOKEN.");
  }
  return axios.create({
    baseURL: figmaConfig.baseUrl,
    headers: { "X-Figma-Token": figmaConfig.accessToken },
    timeout: 60000,
  });
}

async function requestWithRetry<T>(requestFn: () => Promise<T>, retries = 3): Promise<T> {
  let attempt = 0;
  while (true) {
    try {
      return await requestFn();
    } catch (error: any) {
      const status = error.response?.status;
      if (status === 429 && attempt < retries) {
        const retryAfterHeader = error.response?.headers?.["retry-after"];
        const retryAfterMs = Number(retryAfterHeader) > 0
          ? Math.min(Number(retryAfterHeader) * 1000, 15000)
          : 1000 * 2 ** attempt;
        const delayMs = Math.max(1000, retryAfterMs);
        logger.warn(`Figma rate limit detected; retrying in ${delayMs}ms (attempt ${attempt + 1}/${retries})`);
        await new Promise((resolve) => setTimeout(resolve, delayMs));
        attempt += 1;
        continue;
      }
      throw error;
    }
  }
}

export function extractFileKeyFromUrl(url: string): string | null {
  const match = url.match(/(?:file|design|proto|board)\/([a-zA-Z0-9]+)\//);
  return match ? match[1] : null;
}

export function extractNodeIdFromUrl(url: string): string | null {
  try {
    const nodeId = new URL(url).searchParams.get("node-id");
    return nodeId ? nodeId.replace(/-/g, ":") : null;
  } catch { return null; }
}

function figmaColorToCss(c: any): string {
  if (!c) return "transparent";
  const r = Math.round((c.r ?? 0) * 255);
  const g = Math.round((c.g ?? 0) * 255);
  const b = Math.round((c.b ?? 0) * 255);
  const a = c.a ?? 1;
  return a < 1 ? `rgba(${r},${g},${b},${a.toFixed(2)})` : `rgb(${r},${g},${b})`;
}

function extractStyles(node: any): Record<string, unknown> {
  const s: Record<string, unknown> = {};
  const fill = node.fills?.find((f: any) => f.visible !== false && f.type === "SOLID");
  if (fill) s.backgroundColor = figmaColorToCss(fill.color);
  if (node.strokes?.[0]?.color) {
    s.borderColor = figmaColorToCss(node.strokes[0].color);
    s.borderWidth = node.strokeWeight ?? 1;
  }
  if (node.cornerRadius) s.borderRadius = node.cornerRadius;
  if (node.opacity !== undefined && node.opacity < 1) s.opacity = node.opacity;
  const shadow = node.effects?.find((e: any) => e.type === "DROP_SHADOW" && e.visible !== false);
  if (shadow) s.boxShadow = `${shadow.offset?.x ?? 0}px ${shadow.offset?.y ?? 0}px ${shadow.radius ?? 0}px ${figmaColorToCss(shadow.color)}`;
  if (node.layoutMode) {
    s.display = "flex";
    s.flexDirection = node.layoutMode === "VERTICAL" ? "column" : "row";
    if (node.itemSpacing) s.gap = node.itemSpacing;
    if (node.paddingLeft) s.paddingLeft = node.paddingLeft;
    if (node.paddingRight) s.paddingRight = node.paddingRight;
    if (node.paddingTop) s.paddingTop = node.paddingTop;
    if (node.paddingBottom) s.paddingBottom = node.paddingBottom;
  }
  if (node.style) {
    if (node.style.fontFamily) s.fontFamily = node.style.fontFamily;
    if (node.style.fontSize) s.fontSize = node.style.fontSize;
    if (node.style.fontWeight) s.fontWeight = node.style.fontWeight;
  }
  return s;
}

function nodeToDesignSpec(node: any, depth = 0): FigmaDesignSpec {
  const spec: FigmaDesignSpec = {
    component: node.name ?? "Unnamed",
    layout: node.type ?? "UNKNOWN",
    dimensions: {
      width: node.absoluteBoundingBox?.width ?? node.size?.x ?? 0,
      height: node.absoluteBoundingBox?.height ?? node.size?.y ?? 0,
    },
    styles: extractStyles(node),
    children: [],
  };
  if (node.characters) spec.text = node.characters;
  if (depth < 8 && node.children) {
    spec.children = node.children
      .filter((c: any) => c.visible !== false)
      .map((c: any) => nodeToDesignSpec(c, depth + 1));
  }
  return spec;
}

export async function getFileInfo(fileKey: string): Promise<FigmaFileInfo> {
  logger.info(`Fetching Figma file info: ${fileKey}`);
  const client = createClient();
  try {
    const res = await requestWithRetry(() => client.get(`/files/${fileKey}?depth=1`));
    const doc = res.data.document;
    return {
      name: res.data.name, lastModified: res.data.lastModified, version: res.data.version,
      pages: (doc.children ?? []).map((p: any) => ({ name: p.name, id: p.id, childCount: p.children?.length ?? 0 })),
    };
  } catch (error: any) {
    throw new ApiError("Figma", `Failed to fetch file info: ${getErrorMessage(error)}`, error.response?.status);
  }
}

export async function getFile(fileKey: string, depth?: number): Promise<unknown> {
  const client = createClient();
  try {
    const params = depth ? `?depth=${depth}` : "";
    const res = await requestWithRetry(() => client.get(`/files/${fileKey}${params}`));
    return res.data;
  } catch (error: any) {
    throw new ApiError("Figma", `Failed to fetch file: ${getErrorMessage(error)}`, error.response?.status);
  }
}

export async function getNodes(fileKey: string, nodeIds: string[]): Promise<Record<string, unknown>> {
  const client = createClient();
  try {
    const res = await requestWithRetry(() => client.get(`/files/${fileKey}/nodes?ids=${nodeIds.join(",")}`));
    return res.data.nodes ?? {};
  } catch (error: any) {
    throw new ApiError("Figma", `Failed to fetch nodes: ${getErrorMessage(error)}`, error.response?.status);
  }
}

export async function getComponents(fileKey: string): Promise<unknown[]> {
  const client = createClient();
  try {
    const res = await requestWithRetry(() => client.get(`/files/${fileKey}/components`));
    return res.data.meta?.components ?? [];
  } catch (error: any) {
    throw new ApiError("Figma", `Failed to fetch components: ${getErrorMessage(error)}`, error.response?.status);
  }
}

export async function getStyles(fileKey: string): Promise<unknown[]> {
  const client = createClient();
  try {
    const res = await requestWithRetry(() => client.get(`/files/${fileKey}/styles`));
    return res.data.meta?.styles ?? [];
  } catch (error: any) {
    throw new ApiError("Figma", `Failed to fetch styles: ${getErrorMessage(error)}`, error.response?.status);
  }
}

export async function exportImages(fileKey: string, nodeIds: string[], format: "png" | "svg" | "jpg" | "pdf" = "png", scale = 2): Promise<Record<string, string>> {
  const client = createClient();
  try {
    const res = await requestWithRetry(() => client.get(`/images/${fileKey}?ids=${nodeIds.join(",")}&format=${format}&scale=${scale}`));
    return res.data.images ?? {};
  } catch (error: any) {
    throw new ApiError("Figma", `Failed to export images: ${getErrorMessage(error)}`, error.response?.status);
  }
}

export async function getDesignSpec(figmaUrl: string) {
  const fileKey = extractFileKeyFromUrl(figmaUrl);
  if (!fileKey) throw new ApiError("Figma", `Cannot extract file key from URL: ${figmaUrl}`);
  const nodeId = extractNodeIdFromUrl(figmaUrl);
  const fileInfo = await getFileInfo(fileKey);
  let designSpec: FigmaDesignSpec | null = null;
  if (nodeId) {
    const nodes = await getNodes(fileKey, [nodeId]);
    const nodeData = (nodes as any)[nodeId];
    if (nodeData?.document) designSpec = nodeToDesignSpec(nodeData.document);
  } else {
    const fileData = await getFile(fileKey, 3) as any;
    const firstPage = fileData?.document?.children?.[0];
    if (firstPage) designSpec = nodeToDesignSpec(firstPage);
  }
  return { fileInfo, designSpec, nodeId };
}

/**
 * Suggest likely top-level screen node IDs from the first page.
 */
export async function suggestScreenNodeIds(fileKey: string, limit = 5): Promise<string[]> {
  const fileData = await getFile(fileKey, 2) as any;
  const firstPage = fileData?.document?.children?.[0];
  if (!firstPage?.children || !Array.isArray(firstPage.children)) {
    return [];
  }

  const preferredTypes = new Set(["FRAME", "SECTION", "COMPONENT_SET", "COMPONENT"]);
  return firstPage.children
    .filter((node: any) => preferredTypes.has(node.type))
    .slice(0, limit)
    .map((node: any) => node.id)
    .filter((id: unknown): id is string => typeof id === "string");
}
