/**
 * Jira API Client
 * 
 * Provides functions to interact with the Jira Cloud REST API v3.
 * Supports: listing tickets, fetching details, updating status, adding comments,
 * creating issues, and searching.
 */
import axios, { AxiosInstance } from "axios";
import FormData from "form-data";
import { jiraConfig } from "../config.js";
import { logger } from "../utils/logger.js";
import { ApiError, getErrorMessage } from "../utils/errors.js";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface JiraIssue {
  key: string;
  id: string;
  summary: string;
  status: string;
  assignee: string | null;
  priority: string;
  issueType: string;
  description: string | null;
  figmaLink: string | null;
  labels: string[];
  created: string;
  updated: string;
  url: string;
}

export interface JiraTransition {
  id: string;
  name: string;
  to: {
    name: string;
    id: string;
  };
}

export interface JiraComment {
  id: string;
  author: string;
  body: string;
  created: string;
}

export interface JiraAttachment {
  id: string;
  fileName: string;
  size: number;
  mimeType: string;
  content: string;
}

// ---------------------------------------------------------------------------
// Client Factory
// ---------------------------------------------------------------------------

function createClient(): AxiosInstance {
  const { email, apiToken, domain } = jiraConfig;
  if (!email || !apiToken || !domain) {
    throw new ApiError("Jira", "Missing Jira credentials. Set JIRA_EMAIL, JIRA_API_TOKEN, JIRA_DOMAIN.");
  }
  return axios.create({
    baseURL: `https://${domain}/rest/api/3`,
    headers: {
      Authorization: `Basic ${Buffer.from(`${email}:${apiToken}`).toString("base64")}`,
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    timeout: 30000,
  });
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Extract Figma links from Jira's Atlassian Document Format (ADF) description.
 */
function extractFigmaLink(description: unknown): string | null {
  if (!description) return null;
  const descStr = JSON.stringify(description);
  const figmaRegex =
    /https:\/\/(?:www\.)?figma\.com\/(?:file|proto|design|board)\/[a-zA-Z0-9]+\/[^"\\s\\]+/;
  const match = descStr.match(figmaRegex);
  return match ? match[0] : null;
}

/**
 * Flatten ADF description into plain text.
 */
function flattenAdf(node: any): string {
  if (!node) return "";
  if (typeof node === "string") return node;
  if (node.type === "text") return node.text ?? "";
  if (Array.isArray(node.content)) {
    return node.content.map(flattenAdf).join("");
  }
  return "";
}

/**
 * Map raw Jira API issue into our normalized shape.
 */
function mapIssue(issue: any): JiraIssue {
  const fields = issue.fields ?? {};
  return {
    key: issue.key,
    id: issue.id,
    summary: fields.summary ?? "",
    status: fields.status?.name ?? "Unknown",
    assignee: fields.assignee?.displayName ?? null,
    priority: fields.priority?.name ?? "None",
    issueType: fields.issuetype?.name ?? "Unknown",
    description: flattenAdf(fields.description),
    figmaLink: extractFigmaLink(fields.description),
    labels: fields.labels ?? [],
    created: fields.created ?? "",
    updated: fields.updated ?? "",
    url: `https://${jiraConfig.domain}/browse/${issue.key}`,
  };
}

function isResolvedStatus(status: string): boolean {
  const normalized = status.toLowerCase();
  return normalized === "done" || normalized === "resolved" || normalized === "closed";
}

function isIgnoreLabel(labels: string[]): boolean {
  return labels.some((label) => {
    const normalized = label.toLowerCase();
    return normalized === "ignore" || normalized === "accidental";
  });
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Get all issues assigned to the authenticated user.
 */
export async function getAssignedIssues(maxResults = 20): Promise<JiraIssue[]> {
  logger.info("Fetching assigned Jira issues...");
  const client = createClient();
  try {
    const response = await client.post("/search/jql", {
      jql: "assignee = currentUser() ORDER BY updated DESC",
      fields: [
        "summary", "description", "status", "assignee",
        "priority", "issuetype", "labels", "created", "updated",
      ],
      maxResults,
    });
    return (response.data.issues ?? []).map(mapIssue);
  } catch (error: any) {
    const msg = error.response?.data?.errorMessages?.join(", ") ?? getErrorMessage(error);
    throw new ApiError("Jira", `Failed to fetch assigned issues: ${msg}`, error.response?.status);
  }
}

/**
 * Get the latest unresolved issue assigned to the authenticated user.
 */
export async function getLatestUnresolvedIssue(maxResults = 20): Promise<JiraIssue | null> {
  const issues = await getAssignedIssues(maxResults);
  return issues.find((issue) => !isResolvedStatus(issue.status) && !isIgnoreLabel(issue.labels)) ?? null;
}

/**
 * Get a single issue by key or ID.
 */
export async function getIssue(issueKeyOrId: string): Promise<JiraIssue> {
  logger.info(`Fetching Jira issue: ${issueKeyOrId}`);
  const client = createClient();
  try {
    const response = await client.get(`/issue/${issueKeyOrId}`, {
      params: {
        fields: "summary,description,status,assignee,priority,issuetype,labels,created,updated",
      },
    });
    return mapIssue(response.data);
  } catch (error: any) {
    const msg = error.response?.data?.errorMessages?.join(", ") ?? getErrorMessage(error);
    throw new ApiError("Jira", `Failed to fetch issue ${issueKeyOrId}: ${msg}`, error.response?.status);
  }
}

/**
 * Search issues using JQL.
 */
export async function searchIssues(jql: string, maxResults = 20): Promise<JiraIssue[]> {
  logger.info(`Searching Jira issues with JQL: ${jql}`);
  const client = createClient();
  try {
    const response = await client.post("/search/jql", {
      jql,
      fields: [
        "summary", "description", "status", "assignee",
        "priority", "issuetype", "labels", "created", "updated",
      ],
      maxResults,
    });
    return (response.data.issues ?? []).map(mapIssue);
  } catch (error: any) {
    const msg = error.response?.data?.errorMessages?.join(", ") ?? getErrorMessage(error);
    throw new ApiError("Jira", `JQL search failed: ${msg}`, error.response?.status);
  }
}

/**
 * Get available transitions for an issue.
 */
export async function getTransitions(issueKeyOrId: string): Promise<JiraTransition[]> {
  logger.info(`Fetching transitions for: ${issueKeyOrId}`);
  const client = createClient();
  try {
    const response = await client.get(`/issue/${issueKeyOrId}/transitions`);
    return (response.data.transitions ?? []).map((t: any) => ({
      id: t.id,
      name: t.name,
      to: { name: t.to?.name ?? "", id: t.to?.id ?? "" },
    }));
  } catch (error: any) {
    throw new ApiError("Jira", `Failed to get transitions: ${getErrorMessage(error)}`, error.response?.status);
  }
}

/**
 * Transition an issue to a new status.
 */
export async function transitionIssue(issueKeyOrId: string, transitionId: string): Promise<void> {
  logger.info(`Transitioning issue ${issueKeyOrId} with transition ${transitionId}`);
  const client = createClient();
  try {
    await client.post(`/issue/${issueKeyOrId}/transitions`, {
      transition: { id: transitionId },
    });
    logger.info(`Issue ${issueKeyOrId} transitioned successfully.`);
  } catch (error: any) {
    throw new ApiError("Jira", `Failed to transition issue: ${getErrorMessage(error)}`, error.response?.status);
  }
}

/**
 * Update issue status by finding a matching transition name.
 */
export async function updateIssueStatus(issueKeyOrId: string, statusName: string): Promise<string> {
  const transitions = await getTransitions(issueKeyOrId);
  const match = transitions.find(
    (t) => t.name.toLowerCase() === statusName.toLowerCase() ||
           t.to.name.toLowerCase() === statusName.toLowerCase()
  );
  if (!match) {
    const available = transitions.map((t) => `${t.name} → ${t.to.name}`).join(", ");
    throw new ApiError(
      "Jira",
      `No transition matching "${statusName}" found. Available: ${available}`
    );
  }
  await transitionIssue(issueKeyOrId, match.id);
  return `Issue ${issueKeyOrId} transitioned to "${match.to.name}" via "${match.name}".`;
}

/**
 * Add a comment to an issue.
 */
export async function addComment(issueKeyOrId: string, commentText: string): Promise<JiraComment> {
  logger.info(`Adding comment to ${issueKeyOrId}`);
  const client = createClient();
  try {
    const response = await client.post(`/issue/${issueKeyOrId}/comment`, {
      body: {
        type: "doc",
        version: 1,
        content: [
          {
            type: "paragraph",
            content: [{ type: "text", text: commentText }],
          },
        ],
      },
    });
    return {
      id: response.data.id,
      author: response.data.author?.displayName ?? "Unknown",
      body: commentText,
      created: response.data.created,
    };
  } catch (error: any) {
    throw new ApiError("Jira", `Failed to add comment: ${getErrorMessage(error)}`, error.response?.status);
  }
}

/**
 * Get comments for an issue.
 */
export async function getComments(issueKeyOrId: string): Promise<JiraComment[]> {
  logger.info(`Fetching comments for ${issueKeyOrId}`);
  const client = createClient();
  try {
    const response = await client.get(`/issue/${issueKeyOrId}/comment`);
    return (response.data.comments ?? []).map((c: any) => ({
      id: c.id,
      author: c.author?.displayName ?? "Unknown",
      body: flattenAdf(c.body),
      created: c.created,
    }));
  } catch (error: any) {
    throw new ApiError("Jira", `Failed to fetch comments: ${getErrorMessage(error)}`, error.response?.status);
  }
}

/**
 * Download a file from URL and attach it to a Jira issue.
 */
export async function addAttachmentFromUrl(
  issueKeyOrId: string,
  fileUrl: string,
  fileName?: string
): Promise<JiraAttachment[]> {
  logger.info(`Adding attachment to ${issueKeyOrId} from URL`);
  const client = createClient();

  let fileBuffer: Buffer;
  let contentType = "application/octet-stream";
  try {
    const fileRes = await axios.get(fileUrl, {
      responseType: "arraybuffer",
      timeout: 60000,
    });
    fileBuffer = Buffer.from(fileRes.data);
    if (typeof fileRes.headers["content-type"] === "string") {
      contentType = fileRes.headers["content-type"];
    }
  } catch (error: any) {
    throw new ApiError("Jira", `Failed to download attachment URL: ${getErrorMessage(error)}`);
  }

  const inferredName = fileName ?? fileUrl.split("?")[0].split("/").pop() ?? "attachment.bin";
  const form = new FormData();
  form.append("file", fileBuffer, {
    filename: inferredName,
    contentType,
  });

  try {
    const response = await client.post(`/issue/${issueKeyOrId}/attachments`, form, {
      headers: {
        ...form.getHeaders(),
        "X-Atlassian-Token": "no-check",
      },
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    });

    return (response.data ?? []).map((a: any) => ({
      id: a.id,
      fileName: a.filename,
      size: a.size,
      mimeType: a.mimeType,
      content: a.content,
    }));
  } catch (error: any) {
    throw new ApiError("Jira", `Failed to upload Jira attachment: ${getErrorMessage(error)}`, error.response?.status);
  }
}
