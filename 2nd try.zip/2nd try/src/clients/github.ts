/**
 * GitHub API Client
 * 
 * Provides functions for GitHub operations: repos, branches, commits, PRs, and cloning.
 */
import axios, { AxiosInstance } from "axios";
import { execSync } from "child_process";
import { githubConfig } from "../config.js";
import { logger } from "../utils/logger.js";
import { ApiError, getErrorMessage } from "../utils/errors.js";
import dotenv from "dotenv";
import path from "path";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface GitHubRepo {
  name: string;
  fullName: string;
  description: string | null;
  url: string;
  cloneUrl: string;
  defaultBranch: string;
  private: boolean;
  language: string | null;
}

export interface GitHubBranch {
  name: string;
  sha: string;
  protected: boolean;
}

export interface GitHubPullRequest {
  number: number;
  title: string;
  state: string;
  url: string;
  head: string;
  base: string;
  author: string;
  created: string;
}

// ---------------------------------------------------------------------------
// Client Factory
// ---------------------------------------------------------------------------

function createClient(): AxiosInstance {
  // Ensure `.env` is loaded at call-time so newly created .env files are picked up.
  try {
    const envPath = path.resolve(process.cwd(), ".env");
    dotenv.config({ path: envPath });
  } catch (e) {
    // ignore
  }

  const token = process.env.GITHUB_TOKEN || githubConfig.token;
  if (!token) {
    throw new ApiError("GitHub", "Missing GITHUB_TOKEN environment variable.");
  }
  return axios.create({
    baseURL: githubConfig.apiUrl,
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github.v3+json",
    },
    timeout: 30000,
  });
}

// ---------------------------------------------------------------------------
// Repository Operations
// ---------------------------------------------------------------------------

export async function getRepo(owner: string, repo: string): Promise<GitHubRepo> {
  logger.info(`Fetching repo: ${owner}/${repo}`);
  const client = createClient();
  try {
    const res = await client.get(`/repos/${owner}/${repo}`);
    const d = res.data;
    return {
      name: d.name, fullName: d.full_name, description: d.description,
      url: d.html_url, cloneUrl: d.clone_url, defaultBranch: d.default_branch,
      private: d.private, language: d.language,
    };
  } catch (error: any) {
    throw new ApiError("GitHub", `Failed to fetch repo: ${getErrorMessage(error)}`, error.response?.status);
  }
}

export async function listBranches(owner: string, repo: string): Promise<GitHubBranch[]> {
  const client = createClient();
  try {
    const res = await client.get(`/repos/${owner}/${repo}/branches`);
    return res.data.map((b: any) => ({ name: b.name, sha: b.commit.sha, protected: b.protected }));
  } catch (error: any) {
    throw new ApiError("GitHub", `Failed to list branches: ${getErrorMessage(error)}`, error.response?.status);
  }
}

export async function createBranch(owner: string, repo: string, branchName: string, fromBranch?: string): Promise<string> {
  logger.info(`Creating branch ${branchName} in ${owner}/${repo}`);
  const client = createClient();
  try {
    const baseBranch = fromBranch ?? (await getRepo(owner, repo)).defaultBranch;
    const refRes = await client.get(`/repos/${owner}/${repo}/git/ref/heads/${baseBranch}`);
    const sha = refRes.data.object.sha;
    await client.post(`/repos/${owner}/${repo}/git/refs`, {
      ref: `refs/heads/${branchName}`,
      sha,
    });
    return `Branch "${branchName}" created from "${baseBranch}" (${sha.substring(0, 7)})`;
  } catch (error: any) {
    throw new ApiError("GitHub", `Failed to create branch: ${getErrorMessage(error)}`, error.response?.status);
  }
}

// ---------------------------------------------------------------------------
// Pull Request Operations
// ---------------------------------------------------------------------------

export async function createPullRequest(
  owner: string, repo: string, title: string,
  head: string, base: string, body?: string
): Promise<GitHubPullRequest> {
  logger.info(`Creating PR: ${head} → ${base} in ${owner}/${repo}`);
  const client = createClient();
  try {
    const res = await client.post(`/repos/${owner}/${repo}/pulls`, { title, head, base, body });
    const d = res.data;
    return {
      number: d.number, title: d.title, state: d.state, url: d.html_url,
      head: d.head.ref, base: d.base.ref, author: d.user.login, created: d.created_at,
    };
  } catch (error: any) {
    const detail = error.response?.data?.message ?? getErrorMessage(error);
    throw new ApiError("GitHub", `Failed to create PR: ${detail}`, error.response?.status);
  }
}

export async function listPullRequests(owner: string, repo: string, state: "open" | "closed" | "all" = "open"): Promise<GitHubPullRequest[]> {
  const client = createClient();
  try {
    const res = await client.get(`/repos/${owner}/${repo}/pulls?state=${state}`);
    return res.data.map((d: any) => ({
      number: d.number, title: d.title, state: d.state, url: d.html_url,
      head: d.head.ref, base: d.base.ref, author: d.user.login, created: d.created_at,
    }));
  } catch (error: any) {
    throw new ApiError("GitHub", `Failed to list PRs: ${getErrorMessage(error)}`, error.response?.status);
  }
}

export async function mergePullRequest(owner: string, repo: string, prNumber: number, method: "merge" | "squash" | "rebase" = "squash"): Promise<string> {
  const client = createClient();
  try {
    await client.put(`/repos/${owner}/${repo}/pulls/${prNumber}/merge`, { merge_method: method });
    return `PR #${prNumber} merged successfully via ${method}.`;
  } catch (error: any) {
    throw new ApiError("GitHub", `Failed to merge PR: ${getErrorMessage(error)}`, error.response?.status);
  }
}

// ---------------------------------------------------------------------------
// File Operations (via GitHub API — useful when no local clone)
// ---------------------------------------------------------------------------

export async function getFileContent(owner: string, repo: string, path: string, ref?: string): Promise<{ content: string; sha: string }> {
  const client = createClient();
  try {
    const params = ref ? `?ref=${ref}` : "";
    const res = await client.get(`/repos/${owner}/${repo}/contents/${path}${params}`);
    const content = Buffer.from(res.data.content, "base64").toString("utf-8");
    return { content, sha: res.data.sha };
  } catch (error: any) {
    throw new ApiError("GitHub", `Failed to get file content: ${getErrorMessage(error)}`, error.response?.status);
  }
}

export async function createOrUpdateFile(
  owner: string, repo: string, path: string, content: string,
  message: string, branch: string, sha?: string
): Promise<string> {
  const client = createClient();
  try {
    const payload: any = {
      message,
      content: Buffer.from(content).toString("base64"),
      branch,
    };
    if (sha) payload.sha = sha;
    const res = await client.put(`/repos/${owner}/${repo}/contents/${path}`, payload);
    return `File ${path} committed: ${res.data.commit.sha.substring(0, 7)}`;
  } catch (error: any) {
    throw new ApiError("GitHub", `Failed to commit file: ${getErrorMessage(error)}`, error.response?.status);
  }
}

// ---------------------------------------------------------------------------
// Git CLI Operations (for local repo work)
// ---------------------------------------------------------------------------

export function cloneRepository(repoUrl: string, localPath: string): string {
  logger.info(`Cloning ${repoUrl} to ${localPath}`);
  try {
    let authUrl = repoUrl;
    if (githubConfig.token && repoUrl.startsWith("https://github.com/")) {
      authUrl = repoUrl.replace("https://github.com/", `https://x-access-token:${githubConfig.token}@github.com/`);
    }
    execSync(`git clone "${authUrl}" "${localPath}"`, { stdio: "pipe" });
    return `Repository cloned to ${localPath}`;
  } catch (error: any) {
    throw new ApiError("GitHub", `Clone failed: ${getErrorMessage(error)}`);
  }
}

export function gitExec(cwd: string, command: string): string {
  logger.info(`Git exec in ${cwd}: git ${command}`);
  try {
    return execSync(`git ${command}`, { cwd, encoding: "utf-8", stdio: "pipe" }).trim();
  } catch (error: any) {
    throw new ApiError("GitHub", `Git command failed: ${getErrorMessage(error)}`);
  }
}

export function gitCommitAndPush(cwd: string, message: string, branch: string): string {
  gitExec(cwd, "add -A");
  gitExec(cwd, `commit -m "${message.replace(/"/g, '\\"')}"`);
  gitExec(cwd, `push origin ${branch}`);
  return `Changes committed and pushed to ${branch}`;
}
