/**
 * Jira Issue Creation
 * 
 * Extends the Jira client with the ability to create new issues.
 * Used by the Figma webhook watcher to auto-create tickets when designs change.
 */
import axios from "axios";
import { jiraConfig } from "../config.js";
import { logger } from "../utils/logger.js";
import { ApiError, getErrorMessage } from "../utils/errors.js";

export interface CreateIssueParams {
  projectKey: string;
  summary: string;
  description?: string;
  issueType?: string;       // default: "Task"
  assignToSelf?: boolean;   // default: true
  labels?: string[];
  figmaUrl?: string;        // will be embedded in description
}

export interface CreatedIssue {
  key: string;
  id: string;
  url: string;
}

function createClient() {
  const { email, apiToken, domain } = jiraConfig;
  if (!email || !apiToken || !domain) {
    throw new ApiError("Jira", "Missing Jira credentials.");
  }
  return axios.create({
    baseURL: `https://${domain}/rest/api/3`,
    headers: {
      Authorization: `Basic ${Buffer.from(`${email}:${apiToken}`).toString("base64")}`,
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    timeout: 30000,
  });
}

/**
 * Build an ADF (Atlassian Document Format) description body.
 */
function buildAdfDescription(text: string, figmaUrl?: string): object {
  const content: any[] = [];

  // Main description paragraph
  if (text) {
    content.push({
      type: "paragraph",
      content: [{ type: "text", text }],
    });
  }

  // Figma link as a separate paragraph
  if (figmaUrl) {
    content.push({
      type: "paragraph",
      content: [
        { type: "text", text: "Figma Design: " },
        {
          type: "text",
          text: figmaUrl,
          marks: [{ type: "link", attrs: { href: figmaUrl } }],
        },
      ],
    });
  }

  return {
    type: "doc",
    version: 1,
    content,
  };
}

/**
 * Get the current user's account ID (for assignee).
 */
async function getCurrentUserId(): Promise<string> {
  const client = createClient();
  const res = await client.get("/myself");
  return res.data.accountId;
}

/**
 * Create a new Jira issue.
 */
export async function createIssue(params: CreateIssueParams): Promise<CreatedIssue> {
  logger.info(`Creating Jira issue in project ${params.projectKey}: "${params.summary}"`);
  const client = createClient();

  try {
    const fields: any = {
      project: { key: params.projectKey },
      summary: params.summary,
      issuetype: { name: params.issueType ?? "Task" },
    };

    // Build description
    if (params.description || params.figmaUrl) {
      fields.description = buildAdfDescription(
        params.description ?? "",
        params.figmaUrl
      );
    }

    // Labels
    if (params.labels?.length) {
      fields.labels = params.labels;
    }

    // Auto-assign to current user
    if (params.assignToSelf !== false) {
      try {
        const accountId = await getCurrentUserId();
        fields.assignee = { accountId };
      } catch (e) {
        logger.warn(`Could not auto-assign: ${getErrorMessage(e)}`);
      }
    }

    const response = await client.post("/issue", { fields });
    const issue: CreatedIssue = {
      key: response.data.key,
      id: response.data.id,
      url: `https://${jiraConfig.domain}/browse/${response.data.key}`,
    };

    logger.info(`Created issue: ${issue.key} — ${issue.url}`);
    return issue;
  } catch (error: any) {
    const msg = error.response?.data?.errors
      ? JSON.stringify(error.response.data.errors)
      : getErrorMessage(error);
    throw new ApiError("Jira", `Failed to create issue: ${msg}`, error.response?.status);
  }
}
