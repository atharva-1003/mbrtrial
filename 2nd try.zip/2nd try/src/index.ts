/**
 * Universal Automation MCP Server
 * 
 * Production-ready MCP server that integrates GitHub, Jira, and Figma
 * for use with GitHub Copilot Chat (Agent Mode).
 * 
 * Transport: stdio (JSON-RPC over stdin/stdout)
 */

// CRITICAL: Redirect console.log to stderr BEFORE any imports.
// MCP communicates over stdout — any stray console.log will break the protocol.
const _origLog = console.log;
console.log = (...args: unknown[]) => console.error(...args);

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  ListToolsRequestSchema,
  CallToolRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { allTools } from "./tools/definitions.js";
import { handleToolCall } from "./tools/handlers.js";
import { logger } from "./utils/logger.js";

// ═══════════════════════════════════════════════
// Server Setup
// ═══════════════════════════════════════════════

const server = new Server(
  {
    name: "universal-automation-mcp",
    version: "2.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// ═══════════════════════════════════════════════
// MCP Protocol Handlers
// ═══════════════════════════════════════════════

/**
 * ListTools — returns all available tool schemas to Copilot.
 */
server.setRequestHandler(ListToolsRequestSchema, async () => {
  logger.info(`ListTools called — returning ${allTools.length} tools.`);
  return { tools: allTools };
});

/**
 * CallTool — dispatches tool execution.
 */
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  logger.info(`CallTool: ${name}`);
  return handleToolCall(name, (args as Record<string, unknown>) ?? {});
});

// ═══════════════════════════════════════════════
// Main
// ═══════════════════════════════════════════════

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  logger.info("🚀 Universal Automation MCP Server v2.0.0 running on stdio");
  logger.info(`   Tools registered: ${allTools.length}`);
  logger.info("   Ready to accept requests from GitHub Copilot Chat.");
}

main().catch((error) => {
  logger.error(`Fatal server error: ${error}`);
  process.exit(1);
});
