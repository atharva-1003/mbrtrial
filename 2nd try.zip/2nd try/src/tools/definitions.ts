/**
 * MCP Tool Schema Definitions
 * 
 * Each tool is defined with name, description, and JSON Schema input.
 * These are exposed via the MCP ListTools handler.
 */

export interface ToolDefinition {
  name: string;
  description: string;
  inputSchema: {
    type: "object";
    properties: Record<string, unknown>;
    required?: string[];
  };
}

// ═══════════════════════════════════════════════
// JIRA TOOLS
// ═══════════════════════════════════════════════

const jiraTools: ToolDefinition[] = [
  {
    name: "jira_list_my_tickets",
    description: "List all Jira tickets assigned to the current user, sorted by last updated. Returns key, summary, status, priority, and any linked Figma designs.",
    inputSchema: {
      type: "object",
      properties: {
        maxResults: { type: "number", description: "Maximum tickets to return (default: 20)" },
      },
    },
  },
  {
    name: "jira_get_ticket",
    description: "Get full details of a specific Jira ticket by its key (e.g., PROJ-123) or ID. Returns summary, description, status, assignee, priority, labels, and linked Figma URL if present.",
    inputSchema: {
      type: "object",
      properties: {
        ticketKey: { type: "string", description: "Jira issue key (e.g., PROJ-123) or numeric ID" },
      },
      required: ["ticketKey"],
    },
  },
  {
    name: "jira_search",
    description: "Search Jira issues using JQL (Jira Query Language). Example: 'project = MYPROJ AND status = \"In Progress\"'",
    inputSchema: {
      type: "object",
      properties: {
        jql: { type: "string", description: "JQL query string" },
        maxResults: { type: "number", description: "Maximum results (default: 20)" },
      },
      required: ["jql"],
    },
  },
  {
    name: "jira_update_status",
    description: "Update the status of a Jira ticket (e.g., move from 'To Do' to 'In Progress' or 'Done'). Automatically finds the correct workflow transition.",
    inputSchema: {
      type: "object",
      properties: {
        ticketKey: { type: "string", description: "Jira issue key (e.g., PROJ-123)" },
        status: { type: "string", description: "Target status name (e.g., 'In Progress', 'Done', 'In Review')" },
      },
      required: ["ticketKey", "status"],
    },
  },
  {
    name: "jira_add_comment",
    description: "Add a comment to a Jira ticket.",
    inputSchema: {
      type: "object",
      properties: {
        ticketKey: { type: "string", description: "Jira issue key (e.g., PROJ-123)" },
        comment: { type: "string", description: "Comment text to add" },
      },
      required: ["ticketKey", "comment"],
    },
  },
  {
    name: "jira_get_comments",
    description: "Get all comments on a Jira ticket.",
    inputSchema: {
      type: "object",
      properties: {
        ticketKey: { type: "string", description: "Jira issue key (e.g., PROJ-123)" },
      },
      required: ["ticketKey"],
    },
  },
  {
    name: "jira_create_issue",
    description: "Create a new Jira issue/ticket. Supports setting project, summary, description, type, labels, and an optional Figma URL. Auto-assigns to the current user by default.",
    inputSchema: {
      type: "object",
      properties: {
        projectKey: { type: "string", description: "Jira project key (e.g., SCRUM, PROJ)" },
        summary: { type: "string", description: "Issue title/summary" },
        description: { type: "string", description: "Detailed description (optional)" },
        issueType: { type: "string", description: "Issue type (default: Task). Options: Task, Story, Bug, Epic" },
        assignToSelf: { type: "boolean", description: "Auto-assign to current user (default: true)" },
        labels: { type: "array", items: { type: "string" }, description: "Labels to add (optional)" },
        figmaUrl: { type: "string", description: "Figma design URL to link in description (optional)" },
      },
      required: ["projectKey", "summary"],
    },
  },
  {
    name: "jira_attach_figma_images",
    description: "Export images from a Figma file/screen and attach them to a Jira ticket.",
    inputSchema: {
      type: "object",
      properties: {
        ticketKey: { type: "string", description: "Jira issue key (e.g., PROJ-123)" },
        figmaUrl: { type: "string", description: "Figma file/design URL" },
        nodeIds: { type: "array", items: { type: "string" }, description: "Optional node IDs to export" },
        format: { type: "string", enum: ["png", "svg", "jpg", "pdf"], description: "Export format (default: png)" },
        scale: { type: "number", description: "Export scale (default: 2)" },
        fileNamePrefix: { type: "string", description: "Optional prefix for uploaded file names" },
      },
      required: ["ticketKey", "figmaUrl"],
    },
  },
];

// ═══════════════════════════════════════════════
// FIGMA TOOLS
// ═══════════════════════════════════════════════

const figmaTools: ToolDefinition[] = [
  {
    name: "figma_get_design",
    description: "Fetch and parse a Figma design from a URL. Returns structured design data including layout, dimensions, styles (colors, fonts, spacing), and component hierarchy — ready for UI code generation. Accepts full Figma URLs including those with specific node selections.",
    inputSchema: {
      type: "object",
      properties: {
        figmaUrl: { type: "string", description: "Full Figma URL (e.g., https://www.figma.com/design/abc123/...)" },
      },
      required: ["figmaUrl"],
    },
  },
  {
    name: "figma_get_file_info",
    description: "Get high-level information about a Figma file: name, version, last modified date, and list of pages.",
    inputSchema: {
      type: "object",
      properties: {
        fileKey: { type: "string", description: "Figma file key (the ID in the URL after /file/ or /design/)" },
      },
      required: ["fileKey"],
    },
  },
  {
    name: "figma_get_components",
    description: "List all components defined in a Figma file.",
    inputSchema: {
      type: "object",
      properties: {
        fileKey: { type: "string", description: "Figma file key" },
      },
      required: ["fileKey"],
    },
  },
  {
    name: "figma_get_styles",
    description: "List all styles (color, text, effect) defined in a Figma file.",
    inputSchema: {
      type: "object",
      properties: {
        fileKey: { type: "string", description: "Figma file key" },
      },
      required: ["fileKey"],
    },
  },
  {
    name: "figma_export_images",
    description: "Export images for specific Figma nodes. Returns download URLs for the exported images.",
    inputSchema: {
      type: "object",
      properties: {
        fileKey: { type: "string", description: "Figma file key" },
        nodeIds: { type: "array", items: { type: "string" }, description: "Array of node IDs to export" },
        format: { type: "string", enum: ["png", "svg", "jpg", "pdf"], description: "Export format (default: png)" },
        scale: { type: "number", description: "Export scale (default: 2)" },
      },
      required: ["fileKey", "nodeIds"],
    },
  },
  {
    name: "figma_start_watch",
    description: "Start watching a Figma file for design changes. When a change is detected, a Jira ticket is automatically created and assigned to you. The watcher polls the Figma API at a configurable interval.",
    inputSchema: {
      type: "object",
      properties: {
        figmaUrl: { type: "string", description: "Full Figma URL of the file to watch" },
        jiraProjectKey: { type: "string", description: "Jira project key for auto-created tickets (e.g., SCRUM)" },
        pollIntervalSeconds: { type: "number", description: "Polling interval in seconds (default: 60)" },
        labels: { type: "array", items: { type: "string" }, description: "Extra labels for auto-created tickets" },
        targetRepoOwner: { type: "string", description: "GitHub repo owner for linking (optional)" },
        targetRepoName: { type: "string", description: "GitHub repo name for linking (optional)" },
      },
      required: ["figmaUrl", "jiraProjectKey"],
    },
  },
  {
    name: "figma_stop_watch",
    description: "Stop watching a Figma file for changes.",
    inputSchema: {
      type: "object",
      properties: {
        figmaFileKey: { type: "string", description: "Figma file key to stop watching (use figma_watch_status to see active watches)" },
      },
      required: ["figmaFileKey"],
    },
  },
  {
    name: "figma_watch_status",
    description: "Get status of all active Figma file watches, including detected changes and auto-created Jira tickets.",
    inputSchema: {
      type: "object",
      properties: {},
    },
  },
];

// ═══════════════════════════════════════════════
// GITHUB TOOLS
// ═══════════════════════════════════════════════

const githubTools: ToolDefinition[] = [
  {
    name: "github_get_repo",
    description: "Get information about a GitHub repository including name, description, default branch, and language.",
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string", description: "Repository owner (user or org)" },
        repo: { type: "string", description: "Repository name" },
      },
      required: ["owner", "repo"],
    },
  },
  {
    name: "github_list_branches",
    description: "List all branches in a GitHub repository.",
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string", description: "Repository owner" },
        repo: { type: "string", description: "Repository name" },
      },
      required: ["owner", "repo"],
    },
  },
  {
    name: "github_create_branch",
    description: "Create a new branch in a GitHub repository. Optionally specify a source branch (defaults to the repo's default branch).",
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string", description: "Repository owner" },
        repo: { type: "string", description: "Repository name" },
        branchName: { type: "string", description: "Name of the new branch" },
        fromBranch: { type: "string", description: "Source branch to create from (optional, defaults to repo default)" },
      },
      required: ["owner", "repo", "branchName"],
    },
  },
  {
    name: "github_create_pull_request",
    description: "Create a Pull Request in a GitHub repository.",
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string", description: "Repository owner" },
        repo: { type: "string", description: "Repository name" },
        title: { type: "string", description: "PR title" },
        head: { type: "string", description: "Branch containing changes" },
        base: { type: "string", description: "Branch to merge into (e.g., main)" },
        body: { type: "string", description: "PR description (optional)" },
      },
      required: ["owner", "repo", "title", "head", "base"],
    },
  },
  {
    name: "github_list_pull_requests",
    description: "List pull requests in a GitHub repository.",
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string", description: "Repository owner" },
        repo: { type: "string", description: "Repository name" },
        state: { type: "string", enum: ["open", "closed", "all"], description: "Filter by state (default: open)" },
      },
      required: ["owner", "repo"],
    },
  },
  {
    name: "github_merge_pull_request",
    description: "Merge a pull request.",
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string", description: "Repository owner" },
        repo: { type: "string", description: "Repository name" },
        prNumber: { type: "number", description: "Pull request number" },
        method: { type: "string", enum: ["merge", "squash", "rebase"], description: "Merge method (default: squash)" },
      },
      required: ["owner", "repo", "prNumber"],
    },
  },
  {
    name: "github_clone_repository",
    description: "Clone a GitHub repository to a local path. Uses authenticated HTTPS with the configured GitHub token.",
    inputSchema: {
      type: "object",
      properties: {
        repositoryUrl: { type: "string", description: "HTTPS URL of the GitHub repository" },
        localPath: { type: "string", description: "Local directory path to clone into" },
      },
      required: ["repositoryUrl", "localPath"],
    },
  },
  {
    name: "github_commit_and_push",
    description: "Stage all changes, commit with a message, and push to the specified branch in a local repository.",
    inputSchema: {
      type: "object",
      properties: {
        localPath: { type: "string", description: "Path to the local git repository" },
        message: { type: "string", description: "Commit message" },
        branch: { type: "string", description: "Branch to push to" },
      },
      required: ["localPath", "message", "branch"],
    },
  },
  {
    name: "github_get_file",
    description: "Get the content of a file from a GitHub repository (via API, no local clone needed).",
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string", description: "Repository owner" },
        repo: { type: "string", description: "Repository name" },
        path: { type: "string", description: "File path in the repository" },
        ref: { type: "string", description: "Branch or commit ref (optional)" },
      },
      required: ["owner", "repo", "path"],
    },
  },
  {
    name: "github_create_or_update_file",
    description: "Create or update a file in a GitHub repository via the API (commits directly without local clone).",
    inputSchema: {
      type: "object",
      properties: {
        owner: { type: "string", description: "Repository owner" },
        repo: { type: "string", description: "Repository name" },
        path: { type: "string", description: "File path in the repository" },
        content: { type: "string", description: "File content" },
        message: { type: "string", description: "Commit message" },
        branch: { type: "string", description: "Target branch" },
        sha: { type: "string", description: "SHA of file being replaced (required for updates, omit for new files)" },
      },
      required: ["owner", "repo", "path", "content", "message", "branch"],
    },
  },
];

// ═══════════════════════════════════════════════
// SESSION / WORKFLOW TOOLS
// ═══════════════════════════════════════════════

const sessionTools: ToolDefinition[] = [
  {
    name: "session_get_context",
    description: "Get the current session context: active Jira ticket, current repository/branch, linked Figma design, and recent action history.",
    inputSchema: {
      type: "object",
      properties: {},
    },
  },
  {
    name: "session_start_ticket",
    description: "Start working on a Jira ticket. Fetches ticket details, sets it as active, extracts any linked Figma designs, and optionally creates a feature branch. If Figma is rate-limited, it falls back to the latest unresolved ticket and resolves it as a workflow continuation.",
    inputSchema: {
      type: "object",
      properties: {
        ticketKey: { type: "string", description: "Jira issue key (e.g., PROJ-123)" },
        owner: { type: "string", description: "GitHub repo owner (optional — for auto branch creation)" },
        repo: { type: "string", description: "GitHub repo name (optional)" },
        branchPrefix: { type: "string", description: "Branch name prefix (default: 'feature/')" },
      },
      required: ["ticketKey"],
    },
  },
  {
    name: "session_reset",
    description: "Reset the current session, clearing the active ticket, repository, and Figma context.",
    inputSchema: {
      type: "object",
      properties: {},
    },
  },
];

// ═══════════════════════════════════════════════
// AUTOMATION / PIPELINE TOOLS
// ═══════════════════════════════════════════════

const automationTools: ToolDefinition[] = [
  {
    name: "automation_full_pipeline",
    description: "Execute the FULL automation pipeline: Start watching a Figma file → auto-create Jira tickets on changes → provide instructions for Copilot to implement and push code. Returns the setup status and instructions for the autonomous workflow.",
    inputSchema: {
      type: "object",
      properties: {
        figmaUrl: { type: "string", description: "Figma file URL to monitor" },
        jiraProjectKey: { type: "string", description: "Jira project key for tickets" },
        githubOwner: { type: "string", description: "GitHub repo owner" },
        githubRepo: { type: "string", description: "GitHub repo name" },
        pollIntervalSeconds: { type: "number", description: "Figma polling interval in seconds (default: 60)" },
      },
      required: ["figmaUrl", "jiraProjectKey", "githubOwner", "githubRepo"],
    },
  },
];

// ═══════════════════════════════════════════════
// EXPORT ALL TOOLS
// ═══════════════════════════════════════════════

export const allTools: ToolDefinition[] = [
  ...jiraTools,
  ...figmaTools,
  ...githubTools,
  ...sessionTools,
  ...automationTools,
];
