# 🚀 Universal Automation MCP Server

A production-ready **Model Context Protocol (MCP)** server that integrates **GitHub**, **Jira**, and **Figma** with GitHub Copilot Chat — enabling developers to manage their entire workflow through natural language, with **fully automated Figma→Jira→GitHub pipelines**.

## ✨ What It Does

Use Copilot Chat in VS Code as a unified interface to:

- **Jira**: List, search, create, and manage tickets — update status, add comments
- **Figma**: Fetch design specs, parse styles/layout, **watch files for changes**
- **GitHub**: Clone repos, create branches, commit, push, create PRs, merge
- **Automation**: **Auto-detect Figma changes → create Jira tickets → implement & push code**

**Example commands in Copilot Chat:**

```
"List all my Jira tickets"
"Start working on ticket PROJ-123"
"Generate UI code from this Figma file"
"Watch this Figma file and auto-create tickets when designs change"
"Start the full automation pipeline for my project"
"Check for new Figma updates"
```

---

## 🔄 Automation Pipeline

The headline feature — **fully autonomous design-to-code automation**:

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐     ┌──────────────┐
│  Figma Design   │────▶│  Auto-Create     │────▶│  Copilot        │────▶│  GitHub PR   │
│  Change Detected│     │  Jira Ticket     │     │  Implements Code│     │  Created     │
└─────────────────┘     └──────────────────┘     └─────────────────┘     └──────────────┘
```

**How it works:**
1. You tell Copilot: *"Watch my Figma file and auto-implement changes"*
2. The MCP server polls Figma for version changes every 60 seconds
3. When a designer updates the Figma file, a Jira ticket is auto-created
4. You ask Copilot to implement the ticket — it fetches the design spec and generates code
5. Code is pushed to GitHub and a PR is created automatically

**One command to set it up:**
```
"Start the full pipeline: watch <figma-url>, create tickets in SCRUM project, push to owner/repo"
```

---

## 📦 Installation

### Prerequisites

- **Node.js** ≥ 18
- **VS Code** with GitHub Copilot Chat
- API tokens for Jira, Figma, and/or GitHub

### Setup

```bash
# 1. Install dependencies
npm install

# 2. Build
npm run build

# 3. Configure tokens (edit .env or use VS Code input prompts)
cp .env.example .env
# Edit .env with your actual tokens
```

---

## 🔑 API Token Setup

### Jira

1. Go to [Atlassian API Tokens](https://id.atlassian.com/manage-profile/security/api-tokens)
2. Create a new token
3. Set in `.env`:
   ```
   JIRA_EMAIL=your-email@example.com
   JIRA_API_TOKEN=your-token
   JIRA_DOMAIN=your-org.atlassian.net
   ```

### Figma

1. Go to Figma → Settings → Personal Access Tokens
2. Create a new token
3. Set: `FIGMA_ACCESS_TOKEN=your-token`

### GitHub

1. Go to [GitHub Settings → Tokens](https://github.com/settings/tokens)
2. Create a Fine-grained or Classic token with `repo` scope
3. Set: `GITHUB_TOKEN=your-token`

---

## ⚙️ VS Code Configuration

The `.vscode/mcp.json` is pre-configured. To activate:

1. Open this project in VS Code
2. The MCP server will appear in Copilot Chat's tool list
3. VS Code will prompt for your API tokens securely on first use

**Alternative**: Hardcode tokens in `.vscode/mcp.json` `env` section (not recommended for shared repos).

---

## 🧰 Available Tools (29 Total)

### Jira (7 tools)

| Tool | Description |
|------|-------------|
| `jira_list_my_tickets` | List assigned tickets |
| `jira_get_ticket` | Get ticket details |
| `jira_search` | Search with JQL |
| `jira_update_status` | Transition status |
| `jira_add_comment` | Add a comment |
| `jira_get_comments` | Read comments |
| `jira_create_issue` | **Create a new issue** (with optional Figma link) |

### Figma (8 tools)

| Tool | Description |
|------|-------------|
| `figma_get_design` | Parse Figma URL → structured design spec |
| `figma_get_file_info` | File metadata |
| `figma_get_components` | List components |
| `figma_get_styles` | List design styles |
| `figma_export_images` | Export node images |
| `figma_start_watch` | **Start watching** a Figma file for changes |
| `figma_stop_watch` | Stop watching a file |
| `figma_watch_status` | Check watch status & auto-created tickets |

### GitHub (10 tools)

| Tool | Description |
|------|-------------|
| `github_get_repo` | Repository info |
| `github_list_branches` | List branches |
| `github_create_branch` | Create a branch |
| `github_create_pull_request` | Create a PR |
| `github_list_pull_requests` | List PRs |
| `github_merge_pull_request` | Merge a PR |
| `github_clone_repository` | Clone repo locally |
| `github_commit_and_push` | Commit + push |
| `github_get_file` | Read file via API |
| `github_create_or_update_file` | Write file via API |

### Session / Workflow (3 tools)

| Tool | Description |
|------|-------------|
| `session_start_ticket` | Full workflow: fetch ticket → Figma → create branch |
| `session_get_context` | Current ticket, repo, branch, Figma |
| `session_reset` | Clear session |

### Automation (1 tool)

| Tool | Description |
|------|-------------|
| `automation_full_pipeline` | **Full pipeline**: Watch Figma → auto Jira tickets → implementation instructions |

---

## 🔄 Workflow Examples

### Full Automation Pipeline

**User:** "Watch my Figma file and auto-create tickets when the design changes"

**Automated Flow:**
1. `automation_full_pipeline` → Sets up Figma file watcher
2. Designer updates Figma file → Version change detected
3. Jira ticket auto-created with Figma link & assigned to you
4. You say "Check for Figma updates" → `figma_watch_status`
5. "Start working on SCRUM-14" → `session_start_ticket`
6. Copilot fetches design spec → generates implementation
7. `github_commit_and_push` → Code pushed
8. `github_create_pull_request` → PR opened
9. `jira_update_status` → Ticket moved to "Done"

### Manual Ticket Workflow

**User:** "Resolve Jira ticket PROJ-123"

**Flow:**
1. `session_start_ticket` → Fetches ticket + Figma design
2. Jira status → "In Progress"
3. GitHub branch → `feature/proj-123` created
4. Copilot generates implementation
5. Code pushed + PR opened + Ticket closed

---

## 🏗️ Architecture

```
src/
├── index.ts              # MCP server entry (stdio transport)
├── config.ts             # Environment config loader
├── session.ts            # Session context manager
├── clients/
│   ├── jira.ts           # Jira REST API v3 client
│   ├── jira-create.ts    # Jira issue creation
│   ├── figma.ts          # Figma REST API client
│   └── github.ts         # GitHub REST API + git CLI client
├── watcher/
│   └── figma-watcher.ts  # Figma file change poller + auto-ticket creator
├── tools/
│   ├── definitions.ts    # MCP tool schemas (29 tools)
│   └── handlers.ts       # Tool execution logic
└── utils/
    ├── logger.ts         # stderr logger (MCP-safe)
    └── errors.ts         # Structured error types
```

---

## 🛡️ Security

- All tokens via environment variables (never hardcoded)
- VS Code `mcp.json` uses secure input prompts for tokens
- Console output goes to stderr only (stdout reserved for MCP protocol)
- GitHub clone uses `x-access-token` for authenticated HTTPS

---

## 🧪 Development

```bash
# Build
npm run build

# Build and run
npm run dev

# Type-check only
npm run typecheck

# Clean build artifacts
npm run clean
```

---

## 📋 License

MIT
